﻿======================================================
MMD	Villa Fortuna Stage    
======================================================

Author :	Trackdancer.deviantart.com
License: 	Creative Commons
		(BY) Attribution
		(NC) Non-Commercial
		(ND) No Derivative Works
		4.0 License
Developed on MMD:  Version 9.26
Version:  1.0
Release:	01-29-2015



INSTALLATION:

See [ setup.jpg ]


CREDITS:

MirrorWF effect by HarganeP
Tree from SketchUp Warehouse
Software used: SketchUp Make 2014, MMD 9.26, PMD 0.1.3.9, Photoshop 7


RESTRICTIONS & DISCLAIMER:

License: CC-BY-NC-ND

Per the Terms of the License as noted above, specifically:

	BY: Credit or link back if used.
	NC: Non-Commercial use only.
	ND: Do not edit, remove parts for use on other models, or create other versions except for your own personal use.

The full text of the license can be viewed at the link below:
ごとのライセンス条件は、上述した。ライセンスの全文は以下のリンクで見ることができます：

[ http://creativecommons.org/licenses/by-nc-nd/4.0/ ]

- Models are released as FREEWARE for non-commercial, personal use only. 
- No Warranty or Guarantee is given nor implied; use strictly at your own risk.

- モデルは非商用、個人使用のみのためのフリーウェアとしてリリースされます。
- いいえ、保証または保証は、与えられたことも、暗黙的に指定され、自分自身の責任で厳重に使用します。



SUPPORT:

If you need technical assistance with this model, please leave a note on the model's home page in my Deviantart gallery.
このモデルと技術支援が必要な場合は、私のdeviantARTのギャラリーでモデルのホーム·ページ上にメモを残してください。


CONTACT:

trackdancer.deviantart.com
https://twitter.com/Trackdancer

[Doc. Ver. 01.2015]
